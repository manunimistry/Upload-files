#from django.shortcuts import render

# Create your views here.

#from django.shortcuts import render, redirect
#from .forms import FileUploadForm
#from .models import UploadedFile #recently added

#def upload_file(request):
#    if request.method == 'POST':
#        form = FileUploadForm(request.POST, request.FILES)
#        if form.is_valid():
#            form.save()
#            return redirect('upload_success')
#    else:
#        form = FileUploadForm()
#    return render(request, 'file_upload/upload.html', {'form': form})

#def upload_success(request):
#    return render(request, 'file_upload/upload_success.html')


#recently added
# views.py

from django.shortcuts import render, redirect
from .forms import FileUploadForm
from .models import UploadedFile

def upload_file(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            # Save uploaded file to file_path field in UploadedFile model
            uploaded_file = UploadedFile(file_path=request.FILES['file'].name)
            uploaded_file.save()
            return redirect('upload_success')  # Redirect to a success page
    else:
        form = FileUploadForm()
    return render(request, 'upload_form.html', {'form': form})
