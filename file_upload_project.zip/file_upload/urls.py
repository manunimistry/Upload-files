from django.urls import path
from .views import upload_file, upload_success

urlpatterns = [
    path('', upload_file, name='upload_file'),
    path('success/', upload_success, name='upload_success'),
]
